const express = require("express");
const app = express();


const HiredEmail = async (req, res, next) => {

    const { email } = req.body;



}

module.exports = HiredEmail;