
import React from 'react';

const Logo = () => (
    <img src="https://issc.co.in/_next/static/media/issc-logo.032d1b91.svg" alt="Logo" className="company-logo" />
);

export default Logo;
