import React from "react";
import SucessModel from "../../../Components/ProfileSetup/SucessModel";

function Profile_Sucess() {
  return (
    <div>
      <div className="bg-background w-full h-screen">
        <h2 className="heading2 text-center pt-10">Profile Creation</h2>
        <SucessModel />
      </div>
    </div>
  );
}

export default Profile_Sucess;
