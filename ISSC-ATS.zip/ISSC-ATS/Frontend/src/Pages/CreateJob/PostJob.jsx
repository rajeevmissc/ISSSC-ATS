import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import "react-quill/dist/quill.snow.css";
import ReactQuill from "react-quill";

function PostJob() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    position: "Software Engineer",
    office_location: "New York",
    department: "Engineering",
    job_type: "Full Time",
    no_of_seats: "5",
    salary_range_from: "50000",
    salary_range_upto: "100000",
  });

  const [description, setDescription] = useState("<p>We are looking for a skilled Software Engineer to join our team. The candidate should have experience in JavaScript, React, and Node.js.</p>");
  
  // Manually filled organization details
  const orgDetails = ["New York", "USA", "TechCorp", "123456"];

  const handleSubmit = async () => {
    if (!formData.position || !formData.office_location || !formData.department) {
      alert("Please fill all required fields.");
      return;
    }

    const sanitizedDescription = description.replace(/<\/?[^>]+(>|$)/g, ""); // Extract plain text from HTML

    const jobPostData = {
      form: formData,
      description: sanitizedDescription,
      org_details: orgDetails,
    };

    try {
      // POST request to the backend API
      const response = await axios.post('http://localhost:8080/job/post', jobPostData);
      console.log(response.data); // Log response from backend
      alert("Job posted successfully!");
      navigate("/jobs");
    } catch (error) {
      console.error(error);
      alert("An error occurred while posting the job.");
    }
  };

  return (
    <div className="flex bg-white mb-8">
      <div className="w-full bg-background">
        <h2 className="text-center text-2xl font-bold py-8">Create New Job</h2>

        <div className="modalShadow bg-white block m-auto w-4/5 mt-14">
          <div className="flex w-4/5 mt-5 m-auto">
            <div className="w-1/2 mr-1 ml-6">
              <label className="label block line1" htmlFor="position">Position</label>
              <input
                name="position"
                id="position"
                type="text"
                value={formData.position}
                onChange={(e) => setFormData({ ...formData, position: e.target.value })}
                className="input input-bordered w-4/5 max-w-xs"
              />
            </div>

            <div className="w-1/2 mr-1 ml-6">
              <label className="label block line1" htmlFor="office_location">Office Location</label>
              <input
                name="office_location"
                id="office_location"
                type="text"
                value={formData.office_location}
                onChange={(e) => setFormData({ ...formData, office_location: e.target.value })}
                className="input input-bordered w-4/5 max-w-xs"
              />
            </div>
          </div>

          <div className="flex w-4/5 mt-5 m-auto">
            <div className="w-1/2 mr-1 ml-6">
              <label className="label block line1" htmlFor="department">Department</label>
              <input
                name="department"
                id="department"
                type="text"
                value={formData.department}
                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                className="input input-bordered w-4/5 max-w-xs"
              />
            </div>

            <div className="w-1/2 mr-1 ml-6">
              <label className="label block line1" htmlFor="job_type">Job Type</label>
              <select
                onChange={(e) => setFormData({ ...formData, job_type: e.target.value })}
                value={formData.job_type}
                className="select select-bordered w-full max-w-xs font-medium line1"
              >
                <option value="Full Time">Full Time</option>
                <option value="Part Time">Part Time</option>
                <option value="Remote">Remote</option>
                <option value="Project Based">Project Based</option>
                <option value="Hourly">Hourly</option>
              </select>
            </div>
          </div>

          <div className="flex w-4/5 mt-5 m-auto">
            <div className="w-1/2 mr-1 ml-6">
              <label className="label block line1" htmlFor="no_of_seats">No of Seats</label>
              <input
                type="number"
                value={formData.no_of_seats}
                onChange={(e) => setFormData({ ...formData, no_of_seats: e.target.value })}
                className="input input-bordered w-4/5 max-w-xs"
              />
            </div>

            <div className="w-1/2 mr-1 ml-6">
              <label className="label block line1" htmlFor="salary_range_from">Salary From</label>
              <input
                type="number"
                value={formData.salary_range_from}
                onChange={(e) => setFormData({ ...formData, salary_range_from: e.target.value })}
                className="input input-bordered w-4/5 max-w-xs"
              />
            </div>

            <div className="w-1/2 mr-1 ml-6">
              <label className="label block line1" htmlFor="salary_range_upto">Salary Upto</label>
              <input
                type="number"
                value={formData.salary_range_upto}
                onChange={(e) => setFormData({ ...formData, salary_range_upto: e.target.value })}
                className="input input-bordered w-4/5 max-w-xs"
              />
            </div>
          </div>

          <div className="mt-4 w-4/5 m-auto">
            <label className="line1" htmlFor="description">Job Description</label>
            <ReactQuill
              value={description}
              onChange={setDescription}
              className="border w-full h-72"
            />
          </div>

          <div className="flex justify-center my-10">
            <button
              onClick={handleSubmit}
              className="text-lg bg-primary text-white px-5 py-2 rounded-full"
            >
              Post Job
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PostJob;
