import axios from 'axios';

const API_URL = 'http://localhost:8080/ats';

export const createTimesheet = async (data) => {
    return await axios.post(`${API_URL}/create`, data);
};

export const getTimesheets = async () => {
    return await axios.get(`${API_URL}/entries`);
};

export const updateTimesheet = async (id, data) => {
    return await axios.put(`${API_URL}/update/${id}`, data);
};

export const deleteTimesheet = async (id) => {
    return await axios.delete(`${API_URL}/delete/${id}`);
};

